#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <errno.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/uio.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "sfards.h"
#include "miner.h"

#define SFARDS_TASK_INTERVAL0		(10000)
#define SFARDS_TASK_INTERVAL1		(500)

#define SHA256D_MAX_FREQ_OFFSET         (25)

//#define DEBUG_UART
//#define DEBUG_RECV

struct sfards_reg
{
    uint8_t chipid;
    uint8_t unit;
    uint8_t addr;
    uint32_t value;
};

static void sfards_port_status_init(struct sfards_port *port)
{
    memset(port->chip_status,0,sizeof(struct sfards_status) * PORT_MAX_CHIPID);
}

static void sfards_port_status_configure(struct sfards_port *port,int chipid,int freq,
                                         uint32_t init_nonce,uint32_t roll_mhash)
{
    struct sfards_status *status;

    if (!port || chipid <= 0 || chipid > PORT_MAX_CHIPID)
    {
        return;
    }
    status = &port->chip_status[chipid - 1];

    status->freq = freq;
    status->nonce_start = init_nonce;
    status->roll_mhash = roll_mhash;
    status->curpos = 0;
    status->roll_n = 0;
    status->hashrate = 0.0;
    status->score = 0;
}

static void sfards_port_status_reset(struct sfards_port *port,int taskid,int force_restart)
{
    int i;
    struct sfards_status *status;

    status = &port->chip_status[0];
    
    for (i = 0;i < PORT_MAX_CHIPID;i++)
    {
        if (force_restart)
        {
            status->roll_n = 0;
        }
    
        if (status->roll_n == 0)
        {
            gettimeofday(&status->tv_start,NULL);
        }
        status->taskid = taskid;
        status->roll_n++;
        status++;
    }
}

void sfards_port_status_update(struct sfards_port *port,int chipid,int taskid,
                                      uint32_t nonce,int invalid)
{
    struct sfards_status *status;
    float mhash,hashrate,interval;
    struct timeval tv,diff;
    if (!port || chipid <= 0 || chipid > PORT_MAX_CHIPID)
    {
        return;
    }

    status = &port->chip_status[chipid - 1];

    if (invalid)
    {
        status->err_n++;
    }
    else
    {
        status->nonce_n++;
        status->nonce[status->curpos] = nonce;
        status->curpos = (status->curpos + 1) & PORT_STATUS_NONCE_MASK;
        mhash = (nonce - status->nonce_start) / 1000000.0;
        if (status->taskid == taskid)
        {
            mhash += status->roll_mhash * (status->roll_n - 1);
        }
        else
        {
            mhash += status->roll_mhash * (status->roll_n - 2);
        }

        if (mhash > 0.0)
        {
            gettimeofday(&tv,NULL);
            timeval_subtract(&diff, &tv, &status->tv_start);
            interval = diff.tv_sec + 1e-6 * diff.tv_usec;
            hashrate = interval < 1e-3 ?  0.0 : mhash / interval;
            status->hashrate= status->hashrate < 1e-3 ? hashrate 
                                : (status->hashrate + hashrate) * 0.5;
        }
    }
}

static int sfards_port_status_check_dup(struct sfards_port *port,int chipid,uint32_t nonce)
{
    int i;
    struct sfards_status *status;

    if (!port || chipid <= 0 || chipid > PORT_MAX_CHIPID)
    {
        return -1;
    }

    status = &port->chip_status[chipid - 1];

    for (i = 0;i < PORT_STATUS_NONCE_MAX_COUNT;i++)
    {
        if (status->nonce[i] == nonce)
        {
            return 1;
        }
    }
    return 0;
}

void sfards_port_status_get(struct sfards_port *port,int max_chipid,
                            int *nonce_n,int *err_n,int *freq,float *hashrate)
{
    struct sfards_status *status;
    int i;
    
    if (max_chipid > PORT_MAX_CHIPID)
    {
        max_chipid = PORT_MAX_CHIPID;
    }

    status = &port->chip_status[0];
    
    for (i = 0;i < max_chipid;i++)
    {
        nonce_n[i] = status->nonce_n;
        err_n[i] = status->err_n;
        freq[i] = status->freq;
        hashrate[i] = status->hashrate;
        status->roll_n = 0;
        status->hashrate = 0.0; 
        status++;
    }
}

static int sfards_port_setup(struct sfards_port *port,int baud)
{
    const int baudrate[] = {2400,4800,9600,19200,38400,57600,115200,
                            500000,921600,1000000,2000000};
    const speed_t baudspeed[] = {B2400,B4800,B9600,B19200,B38400,B57600,B115200,
                                 B500000,B921600,B1000000,B2000000};
    struct termios options;
    int index;
    for (index = 0;index < sizeof(baudrate) / sizeof(int);index++)
    {
        if (baudrate[index] == baud)
        {
            break;
        }
    }

    if (index >= sizeof(baudrate)/sizeof(int))
    {
        return -1;
    }

    if (tcgetattr(port->fd,&options) < 0)
    {
        return -1;
    }

    cfsetspeed(&options,baudspeed[index]);

    options.c_cflag &= ~(CSIZE | PARENB);
    options.c_cflag |= CS8;
    options.c_cflag |= CREAD;
    options.c_cflag |= CLOCAL;

    options.c_iflag &= ~(IGNBRK | BRKINT | PARMRK |
                         ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    options.c_oflag &= ~OPOST;
    options.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);

    options.c_cc[VTIME] = (cc_t)10;
    options.c_cc[VMIN] = 0;

    tcflush(port->fd, TCIFLUSH);
    
    if (tcsetattr(port->fd,TCSANOW, &options) < 0)
    {
        return -1;
    }

    memset(&options,0,sizeof(options));    
    if (tcgetattr(port->fd,&options) < 0)
    {
        return -1;
    }
    port->baud = baud;
    port->interval = 32 * 1000000 * 5 / baud + 1;
    return 0;
}

static int sfards_port_write(struct sfards_port *port,uint8_t chipid,uint8_t unit,
                             uint8_t addr,uint32_t *data,int count)
{
    struct iovec iov[2];
    uint8_t hdr[4] = {0x55,};
    uint8_t *p = (uint8_t *)data;
    int total = count * 4 + 4;
    int offset = 0;
    int len;

    hdr[1] = chipid;
    hdr[2] = unit;
    hdr[3] = addr;
#ifdef DEBUG_UART
    printf("%2.2x%2.2x%2.2x%2.2x ",hdr[0],hdr[1],hdr[2],hdr[3]);
    for (len = 0;len < count * 4;len++)
    {
        printf("%2.2x",p[len]);
        if (len % 32 == 31) printf("\n");
    }
    printf("\n");
#endif
    while(offset < total)
    {
        if (offset < 4)
        {    
            iov[0].iov_base = hdr + offset;
            iov[0].iov_len = 4 - offset;
            iov[1].iov_base = p;
            iov[1].iov_len = count * 4;
            len = writev(port->fd,iov,2);
        }
        else
        {
            len = write(port->fd,p + offset - 4,total - offset);
        }
        if (len <= 0)
        {
            return -1;
        }
        offset += len;
    }    
    fsync(port->fd);
    usleep(port->interval);

    return count;
}

static int sfards_port_read(struct sfards_port *port,uint8_t chipid,uint8_t unit,
                            uint8_t addr,struct sfards_rpt *values,int count,int timeout)
{
#define RDBUF_SIZE	(256)
    fd_set rfds;
    struct timeval tv;
    uint8_t buf[RDBUF_SIZE];
    int offset = 0;
    int len,start,n;
    uint32_t zero = 0x00;
    uint8_t cpm = unit == 0xf0 ? 0x00 : 0x04;
 
    if (sfards_port_write(port,chipid,unit,addr | 0x80,&zero,1) <= 0)
    {
        return -1;
    }
    
    tv.tv_sec = timeout;
    tv.tv_usec = 0;
    n = 0;

    for (;;)
    {
        FD_ZERO(&rfds);
        FD_SET(port->fd, &rfds);
        if (select(port->fd + 1, &rfds, NULL, NULL, &tv) <= 0)
        {
            break;
        }
        
        len = read(port->fd,buf + offset,RDBUF_SIZE - offset);
        if (len <= 0)
        {
            return -1;
        }
        offset += len;
        start = 0;
        while(offset - start >= 8)
        {
            if (buf[start] == 0x55)
            {
                if ((chipid == 0xff || buf[start + 1] == chipid)
                    && buf[start + 2] == cpm 
                    && buf[start + 3] == addr)
                {
                    values[n].chipid = buf[start + 1];
                    memcpy(&values[n].data,buf + start + 4,4);
                    if (++n == count)
                    {
                        return count;
                    }
                }
                start += 7;
            }
            start++;
        }
        memmove(buf,buf + start,offset - start);
        offset -= start;
    }
    return n;
}

static uint32_t sfards_port_calc_baud(int baud)
{
    uint32_t val = 0xb400001f;
    uint32_t div1 = (25000000 / 8) / baud;
    uint32_t div0 = ((25000000 / 8) - div1 * baud) * 1024 / baud;

    val |= div1 << 8 | div0 << 16;
    return val;
}

static uint32_t sfards_port_calc_freq(int freq)
{
    uint32_t pll_od,pll_f;
    if (freq <= 100)
    {
        pll_od = 25;
        pll_f = freq;
    }
    else if (freq <= 600)
    {
        pll_od = 5;
        pll_f = freq / 5;
    }
    else
    {
        pll_od = 1;
        pll_f = freq / 25;
    }

    return (0x0000600d | (pll_f << 17) | (pll_od << 24));
}

static int sfards_port_scrypt_configure(struct sfards_port *port,int freq)
{
    int i;
    uint32_t nonce_step = 0x40000000U / ((port->chip_n + 3) >> 2);
    uint32_t cmd_disable = 0x00000000;
    uint32_t cmd_enable = 0x00000003;
    uint32_t cmd_en_pll   = 0x7fffffff;
    uint32_t cmd_cmp_mode = 0x8000000a;
    uint32_t cmd_init_nonce = 0x00000000;
    uint32_t cmd_set_freq = sfards_port_calc_freq(freq);

    if (sfards_port_write(port,0xff,0xf0,0x00,&cmd_set_freq,1) != 1)
    {
        return -1;
    }

    if (sfards_port_write(port,0xff,0xf0,0x1e,&cmd_disable,1) != 1)
    {
        return -1;
    }

    if (sfards_port_write(port,0xff,0xf0,0x1e,&cmd_enable,1) != 1)
    {
        return -1;
    }

    if (sfards_port_write(port,0xff,0xf0,0x02,&cmd_en_pll,1) != 1)
    {
        return -1;
    }

    if (sfards_port_write(port,0xff,0xbf,0x30,&cmd_cmp_mode,1) != 1)
    {
        return -1;
    }

    for (i = 1;i <= PORT_MAX_CHIPID;i++)
    {
        if (port->chip_map & (1 << i))
        {
            if (sfards_port_write(port,i,0xbf,0x00,&cmd_init_nonce,1) != 1)
            {
                return -1;
            }
            sfards_port_status_configure(port,i,port->freq,cmd_init_nonce,nonce_step / 1000000);
            cmd_init_nonce += nonce_step;
        }
    }
    
    return 0;    
}

static int sfards_port_scrypt_configure_once(struct sfards_port *port)
{

    if (sfards_port_scrypt_configure(port,port->freq) < 0)
    {
        return -1;
    }

    return 0;
}

static int sfards_port_sha256d_vendor_init(struct sfards_port *port)
{
    int i;
    struct sfards_reg vendor_init[10] = 
    {
        {0xff,0xf0,0x54,0x8a5a0002},
        {0xff,0xf0,0x52,0x12a79568},
        {0xff,0xf0,0x55,0x2a7f3382},
        {0xff,0xf0,0x58,0x20141119},
        {0xff,0xf0,0x5a,0x20000000},
        {0xff,0xf0,0x5c,0x00001002},
        {0xff,0xf0,0x60,0x20140619},
        {0xff,0xf0,0x64,0x40961024},
        {0xff,0xf0,0x66,0x1203aaff},
        {0xff,0xf0,0x6a,0x30002201}
    };    
    for (i = 0;i < 10;i++)
    {
        if (sfards_port_write(port,vendor_init[i].chipid,
                                   vendor_init[i].unit,
                                   vendor_init[i].addr,
                                   &vendor_init[i].value,1) != 1)
        {
            return -1;
        }
    }
    return 0;
}

static int sfards_port_sha256d_enable_coreclk(struct sfards_port *port,int chipid)
{
    int i,k;
    uint32_t value = 0x00000001;
    for (i = 0;i < 8;i++)
    {
        for (k = 2;k <= 6;k++)
        {
            if (sfards_port_write(port,chipid,0xf0,k,&value,1) != 1)
            {
                return -1;
            }
            if (value == 0x00000007 && k == 4) 
            {
                value = 0x07ffffff;
            }
        }
        value = ((value << 1) | 1);
    }
    return 0;
}

static int sfards_port_sha256d_configure(struct sfards_port *port,int chipid,int freq,int ref_freq)
{
    int i;
    uint32_t cmd_disable = 0x00000000;
    uint32_t cmd_enable = 0x00000003;
    uint32_t cmd_clean[] = {0,0,0,0,0};
    uint32_t cmd_fill = 0xffffffff;
    uint32_t cmd_mode = 0x17e70c08;
    uint32_t cmd_init_nonce = (0xFFFFFFFF / ref_freq + 1) * (ref_freq - freq);
    uint32_t cmd_set_freq = sfards_port_calc_freq(freq);

    if (sfards_port_write(port,chipid,0xf0,0x00,&cmd_set_freq,1) != 1)
    {
        return -1;
    }

    if (sfards_port_write(port,chipid,0xf0,0x02,cmd_clean,5) != 5)
    {
        return -1;
    }

    if (sfards_port_write(port,chipid,0xf0,0x1e,&cmd_disable,1) != 1)
    {
        return -1;
    }

    if (sfards_port_write(port,chipid,0xf0,0x1e,&cmd_enable,1) != 1)
    {
        return -1;
    }

    if (sfards_port_write(port,chipid,0xef,0x1f,&cmd_mode,1) != 1)
    {
        return -1;
    }

    if (sfards_port_write(port,chipid,0xef,0x01,&cmd_fill,1) != 1)
    {
        return -1;
    }

    for (i = 0 ;i <= 0x60;i += 0x20)
    {
        if (sfards_port_write(port,chipid,0xef,0x00 | i,&cmd_init_nonce,1) != 1)
        {
            return -1;
        }
    }
    
    sfards_port_status_configure(port,chipid,freq,cmd_init_nonce,4295 * freq / ref_freq);

    if (sfards_port_sha256d_enable_coreclk(port,chipid) < 0)
    {
        return -1;
    }

    return 0;
}

static int sfards_port_sha256d_scan(struct sfards_port *port,int *initfreq);

static int sfards_port_sha256d_profile(struct sfards_port *port)
{
    int initfreq[PORT_MAX_CHIPID];
    int i;

    if (sfards_port_sha256d_scan(port,initfreq) < 0)
    {
        return -1;
    }

    for (i = 1;i <= PORT_MAX_CHIPID;i++)
    {
        if (port->chip_map & (1 << i))
        {
            if (sfards_port_sha256d_configure(port,i,initfreq[i - 1],
                                              port->freq + SHA256D_MAX_FREQ_OFFSET) < 0)
            {
                  return -1;
            }
        }
    }
    
    return 0;
}

static int sfards_port_sha256d_configure_once(struct sfards_port *port)
{
    int initfreq[PORT_MAX_CHIPID];
    int i;

    if (sfards_port_sha256d_vendor_init(port) < 0)
    {
        return -1;
    }

    if (sfards_port_sha256d_profile(port) < 0)
    {
        return -1;
    }

    return 0;
}
    
static int sfards_port_detect(struct sfards_port *port)
{
    int n;    
    uint32_t cmd_auto_cfg = 0xc0000001;
    struct sfards_rpt devid[8];
    char *str_type[3] = {"","Scrypt","Sha256"};
    char map[9] = "--------";
    int chips = sfards_port_read(port,0xff,0xf0,0x75,devid,8,2);
   
    port->chip_map = 0;
    port->chip_n = 0;
    
    if (chips <= 0)
    {
        return -1;
    }

    if (devid[0].chipid == 0) // unconfigured
    {
        if (sfards_port_write(port,0xfe,0xf0,0x7f,&cmd_auto_cfg,1) != 1)
        {
            return -1;
        }
        sleep(2);
        chips = sfards_port_read(port,0xff,0xf0,0x75,devid,8,2);
        if (chips <= 0)
        {
            return -1;
        }
    }
    
    if (devid[0].chipid == 0 
        || devid[0].chipid > PORT_MAX_CHIPID 
        || (devid[0].data != 0x47433281 && devid[0].data != 0x4743328B))
    {
        return -1;
    }

    port->chip_map |= 1 << devid[0].chipid;
    port->chip_n++;
    map[devid[0].chipid - 1] = '+';

    for (n = 1;n < chips;n++)
    {
        if (devid[n].data == devid[0].data
            && devid[n].chipid > 0 
            && devid[n].chipid <= PORT_MAX_CHIPID
            && ((1 << devid[n].chipid) & port->chip_map) == 0)
        {
            port->chip_map |= 1 << devid[n].chipid;
            port->chip_n++;
            map[devid[n].chipid - 1] = '+';
        }
    }

    if (devid[0].data == 0x47433281)
    {
        port->type = PORT_TYPE_SCRYPT;

    }
    else //if (devid[0].data == 0x4743328B)
    {
        port->type = PORT_TYPE_SHA256;

    }

    applog(LOG_INFO,"Found %s Port(%s) Chips: %d Map: %s\n",
                     str_type[port->type],port->path,port->chip_n,map);
    return 0;
}

static int sfards_port_configure(struct sfards_port *port,enum PORT_TYPE type)
{
    if (type != PORT_TYPE_UNKNOWN && type != port->type)
    {
        return -1;
    } 

    sfards_port_status_init(port);

    if (port->type == PORT_TYPE_SCRYPT)
    {
        return sfards_port_scrypt_configure_once(port);
    }
    else if (port->type == PORT_TYPE_SHA256)
    {
        return sfards_port_sha256d_configure_once(port);
    }

    return -1;
}

void sfards_port_close(struct sfards_port *port)
{
    close(port->fd);
    port->fd = -1;
}

int sfards_port_open(struct sfards_dev *dev,int index)
{
    struct sfards_port *port = &dev->port[index];
    struct epoll_event ev;

    port->fd = open(port->path,O_RDWR | O_NOCTTY | O_SYNC);
    if (port->fd < 0)
    {
        applog(LOG_ERR,"Failed to open port %s\n",port->path);
        return -1;
    }
    if (sfards_port_setup(port,115200) < 0)
    {
        applog(LOG_ERR,"Failed to setup port %s\n",port->path);
        sfards_port_close(port);
        return -1;
    }

    if (sfards_port_detect(port) < 0)
    {
        applog(LOG_ERR,"Can't find sfards port(%s)\n",port->path);
        sfards_port_close(port);
        return -1;
    }
    
    port->recv_offset = 0; 
    port->ridx = 0;
    port->widx = 0;

    ev.events = EPOLLIN;
    ev.data.ptr = port;
    epoll_ctl(dev->epollfd,EPOLL_CTL_ADD,port->fd,&ev);
    
    if (port->id >= 1 && port->id <= 3)
    {
        dev->port_map |= 1 << (port->id - 1);
    }
    
    if (sfards_port_configure(port,dev->type) < 0)
    {
        applog(LOG_ERR,"Failed to configure port\n",port->path);
        sfards_port_close(port);
        return -1;
    }
   
    return 0;
}

static void *sfards_port_process(void *arg)
{
#define MAX_EVENTS 5    

    struct sfards_dev *dev = (struct sfards_dev *)arg;
    struct epoll_event ev,events[MAX_EVENTS];
    int nfds,i;
 
    while ((nfds = epoll_wait(dev->epollfd, events, MAX_EVENTS, -1)) > 0)
    {
        for (i = 0;i < nfds;i++)
        {
            if (events[i].data.ptr != NULL)
            {
                int len,k;
                struct sfards_port *port = (struct sfards_port *)events[i].data.ptr;
                len = read(port->fd,port->recv_buf + port->recv_offset,
                           PORT_BUF_SIZE - port->recv_offset);
                if (len > 0)
                {
                    port->recv_offset += len;
                    
                    for (k = 0;k <= port->recv_offset - 8;k++)
                    {                    
                        if (port->recv_buf[k] == 0x55)
                        {
                            if ((port->recv_buf[k + 2] & 0x80)
                                && ((port->widx + 1) & PORT_NONCE_RPT_MASK) != port->ridx)
                            {
                                port->nonce[port->widx].chipid = port->recv_buf[k + 1] & 15;
                                port->nonce[port->widx].taskid = port->recv_buf[k + 3] & 3;
                                port->nonce[port->widx].data =   port->recv_buf[k + 4] 
                                                               | port->recv_buf[k + 5] << 8
                                                               | port->recv_buf[k + 6] << 16
                                                               | port->recv_buf[k + 7] << 24;
                                port->widx = (port->widx + 1) & 127;
                                pthread_cond_signal(&port->cond);
                            }
#ifdef DEBUG_RECV
                            {
                                int l;
                                printf("Recv: ");
                                for (l = 0;l < 8;l++)
                                {
                                    printf("%2.2x ",port->recv_buf[k + l]);
                                }
                                printf("\n");
                            }
#endif
                            k += 7;
                        }
                    }
                    if (k > 0) 
                    {
                        memmove(port->recv_buf,port->recv_buf + k,port->recv_offset - k);
                        port->recv_offset -= k; 
                    }
                }
                else
                {
                    sfards_port_close(port);
                }
            }
            else
            {
                uint8_t c = 0;
                if (read(dev->pipefd[0],&c,1) <= 0 || c == 0xFF)
                {
                    return NULL;
                }
            }
        }
    }

    return NULL;
}

static inline int sfards_thr_exit(struct sfards_dev *dev)
{
    uint8_t c = 0xFF;
    return write(dev->pipefd[1],&c,1);
}

struct sfards_dev * sfards_new(enum PORT_TYPE type)
{
    struct epoll_event ev;
    struct sfards_dev *dev;
    int i;
    dev = (struct sfards_dev *)malloc(sizeof(struct sfards_dev));
    if (dev != NULL)
    {
        memset(dev,0,sizeof(struct sfards_dev));

        dev->type = type;
        dev->epollfd = -1;
        dev->pipefd[0] = -1;
        dev->pipefd[1] = -1;
        dev->thr = 0;
        dev->exit = 0;

        for (i = 0;i < PORT_MAX_COUNT;i++)
        {
            pthread_mutex_init(&dev->port[i].lock,NULL);
            pthread_cond_init(&dev->port[i].cond,NULL);
            dev->port[i].fd = -1;
        }

        if (pipe(dev->pipefd) < 0)
        {
            sfards_destroy(dev);
            return NULL;
        }
        
        dev->epollfd = epoll_create(5);
        if (dev->epollfd < 0)
        {
            sfards_destroy(dev);
            return NULL;
        }
        
        ev.events = EPOLLIN;
        ev.data.ptr = NULL;
        epoll_ctl(dev->epollfd,EPOLL_CTL_ADD,dev->pipefd[0],&ev);
         
        if (pthread_create(&dev->thr,NULL,sfards_port_process,dev) < 0)
        {
            sfards_destroy(dev);
            return NULL;
        }
    }
    return dev;
}

int sfards_port_addnew(struct sfards_dev *dev,int index,const char *path,int id,int freq)
{
    struct sfards_port *port;
    
    if (index >= PORT_MAX_COUNT || !path || strlen(path) > 63)  
    {
        return -1;
    }

    freq = freq > 600 ? freq / 25 * 25 : freq / 5 * 5;
   
    port = &dev->port[index];
    sfards_port_close(port);
    memset(port,0,sizeof(struct sfards_port));
    strcpy(port->path,path);
    port->id = id;
    port->freq = freq;
    if (id != 0)
    {
        freq += SHA256D_MAX_FREQ_OFFSET;
    }
    //port->rolltime = 4295L * 1000L / ((freq + SHA256D_MAX_FREQ_OFFSET) * 160 / 1000) + 1000;
    port->rolltime = 4295L * 1000L / (freq * 160 / 1000) + 500;
    
    port->fd = -1;
    port->recv_offset = 0; 
    port->ridx = 0;
    port->widx = 0;
    
    if (id >= 1 && id <= 3)
    {
        port->sockfd = socket(AF_INET,SOCK_DGRAM, 0);
    }
    else
    {
        port->sockfd = -1;
    } 

    return 0;
}

int sfards_dispatch_scrypt_task(struct sfards_port *port,
                                const uint32_t *ptarget,const uint32_t *midstate,
                                const uint32_t *pdata)
{
    uint32_t job[35];

    memcpy(&job[0],ptarget,32);
    memcpy(&job[8],midstate,32); 
    memcpy(&job[16],pdata,76);

    if (sfards_port_write(port,0xff,0xbf,0x01,job,35) != 35)
    {
        return -1;
    }

    port->ridx = port->widx;
    sfards_port_status_reset(port,0,1);

    return 0;
}

int sfards_dispatch_sha256d_task(struct sfards_port *port,int taskid,
                                 const uint32_t *ptarget,const uint32_t *midstate,
                                 const uint32_t *pdata2,uint32_t ntime)
{
    uint32_t job[12] = {0,};
    int i;

    job[0] = ptarget[6];
    memcpy(&job[1],midstate,8 * 4);
    job[9] = pdata2[0];
    job[11] = pdata2[2];

    if (sfards_port_write(port,0xff,0xef,0x01 | taskid << 5,job,9) != 9)
    {
        return -1;
    }

    usleep(SFARDS_TASK_INTERVAL0);

    for (i = 1;i <= PORT_MAX_CHIPID;i++)
    {
        if (port->chip_map & (1 << i)) 
        {
            job[10] = swab32(ntime + i - 1);
            if (sfards_port_write(port,i,0xef,0x0a | taskid << 5,&job[9],3) != 3)
            {
                return -1;
            }
            usleep(SFARDS_TASK_INTERVAL1);
        }
    }
    sfards_port_status_reset(port,taskid,0);
    return 0;
}

int sfards_wait_nonce(struct sfards_port *port,
		      struct sfards_rpt *nonce_rpt,int size,struct timespec *ts)
{
    struct sfards_rpt *rpt = nonce_rpt;
    int i,count = 0;
    while(count == 0)
    {
        while (port->ridx != port->widx && count < size)
        {
            *rpt = port->nonce[port->ridx];
            port->ridx = (port->ridx + 1) & PORT_NONCE_RPT_MASK;
            
            for (i = 0;i < count;i++)
            {
                if (memcmp(&nonce_rpt[i],rpt,sizeof(struct sfards_rpt)) == 0)
                {
                    break;
                }
            } 
            
            if (i < count 
                || sfards_port_status_check_dup(port,rpt->chipid,rpt->data) != 0)
            {
                continue;
            }
            
            count++;
            rpt++;
        }

        if (count == 0) 
        {
            struct timespec now;
            clock_gettime(CLOCK_REALTIME, &now);
            if (now.tv_sec > ts->tv_sec 
                || (now.tv_sec == ts->tv_sec && now.tv_nsec > ts->tv_nsec))
            {
                break;
            }

            pthread_mutex_lock(&port->lock);
            
            if (ETIMEDOUT == pthread_cond_timedwait(&port->cond,&port->lock, ts))
            {
                pthread_mutex_unlock(&port->lock);
                break;
            }
            pthread_mutex_unlock(&port->lock);                
        }
    }

    return count;
}

static int sfards_port_sha256d_test(struct sfards_port *port,int rolltime,int loop,int *correct,int *error)
{
    uint32_t cmd_stop_task = 0x00000003;
    const uint32_t job[12] =
    {
        0xeffffffe,
        0x64b659db,0x7c753d95,0x435e226f,0x3535dfa7,
        0x52bcc649,0x469fa82f,0x72246fb1,0x6a8d45b4,
        0x183c50a3,0x7a7fe16c,0x1f7bebdc
    };
    const uint32_t result[9][4] =
    {
        {0,},
        {1,0xa3bbcd1b,0,0,},
        {1,0x5d61118a,0,0,},
        {2,0x29121191,0x99a382fb,0,},
        {3,0x1f499f06,0x3b793f2d,0x108aea82,},
        {1,0x74f695b9,0,0,},
        {2,0x12688fe2,0x3824cfad,0,},
        {3,0x1b39960c,0x60b14a17,0xef7d24a1,},
        {1,0x46734541,0,0,},
    };
    struct sfards_rpt nonce_rpt[8];
    struct timespec ts;
    uint32_t target[8];
    uint32_t ntime;
    int count,i,k,l;
    int error_n[9] = {0,};
    int nonce_n[9] = {0,0};
    clock_gettime(CLOCK_REALTIME, &ts);
    timespec_add(&ts,rolltime);

    while(sfards_wait_nonce(port,nonce_rpt,8,&ts));
    if (sfards_port_write(port,0xff,0xef,0x1e,&cmd_stop_task,1) != 1)
    {
        return -1;
    }
    clock_gettime(CLOCK_REALTIME, &ts);
    timespec_add(&ts,5000L);

    while(sfards_wait_nonce(port,nonce_rpt,8,&ts));

    target[6] = job[0];
    ntime = swab32(job[10]);
    if (sfards_dispatch_sha256d_task(port,0,target,&job[1],&job[9],ntime))
    {
        return -1;
    }

    clock_gettime(CLOCK_REALTIME, &ts);
    for (l = 0;l < loop;l++)
    {
        timespec_add(&ts,rolltime);
        do
        {
            count = sfards_wait_nonce(port,nonce_rpt,8,&ts);
            for (i = 0;i < count;i++)
            {
                uint32_t nonce = nonce_rpt[i].data;
                int chipid = nonce_rpt[i].chipid;
                if ((port->chip_map & (1 << chipid)) == 0)
                {
                    continue;
                }
                if (nonce_rpt[i].taskid != 0)
                {
                    error_n[chipid]++;
                }
                else
                {
                    for (k = 0;k < result[chipid][0];k++)
                    {
                        if (nonce == result[chipid][k + 1])
                        {
                            nonce_n[chipid]++;
                            break;
                        }
                    }
                    if (k == result[chipid][0])
                    {
                        error_n[chipid]++;
                    }
                }
            }
        }while(count > 0);
    }

    for (i = 1;i <= 8;i++)
    {
        correct[i] = nonce_n[i] * 100 / (result[i][0] * loop);
        error[i] = error_n[i] / result[i][0];
    }

    if (sfards_port_write(port,0xff,0xef,0x1e,&cmd_stop_task,1) != 1)
    {
        return -1;
    }

    clock_gettime(CLOCK_REALTIME, &ts);
    timespec_add(&ts,5000L);

    while(sfards_wait_nonce(port,nonce_rpt,8,&ts));

    return 0;
}

static int sfards_port_sha256d_scan(struct sfards_port *port,int *initfreq)
{
    int correct[9],error[9];
    int upper = port->freq < 975 ? port->freq + 25 : 1000;
    int freq  = port->freq >= 100 ? port->freq - 50 : port->freq;
    int rolltime,invalid,shortfall,redundance,i;

    for (i = 1;i <= PORT_MAX_CHIPID;i++)
    {
        port->maxfreq[i - 1] = freq; 
        initfreq[i - 1] = 0;
    }
 
    while(freq <= upper)
    {
        rolltime = 4295L * 1000L / (freq * 160 / 1000) + 500;
        if (sfards_port_sha256d_configure(port,0xff,freq,freq) < 0)
        {
            return -1;
        } 
        
        memset(correct,0,sizeof(int) * 9);
        memset(error,0,sizeof(int) * 9);
        if (sfards_port_sha256d_test(port,rolltime,10,correct,error) < 0)
        {
            return -1;
        }
/*
        printf("Test Freq : %d MHz %d(%d) %d(%d) %d(%d) %d(%d) %d(%d) %d(%d) %d(%d) %d(%d)\n",freq,
                            correct[1],error[1],correct[2],error[2],correct[3],error[3],correct[4],error[4],
                            correct[5],error[5],correct[6],error[6],correct[7],error[7],correct[8],error[8]);
*/
        for (i = 1;i <= PORT_MAX_CHIPID;i++)
        {
            if ((port->chip_map & (1 << i)) && correct[i] >= 90 && error[i] <= 1)
            {
                port->maxfreq[i - 1] = freq;
            }
        }
        freq += freq >= 600 ? 25 : 5;
    }

    shortfall = 0;
    redundance = 0;

    for (i = 1;i <= PORT_MAX_CHIPID;i++)
    {
        if (port->chip_map & (1 << i))
        {
            initfreq[i - 1] = port->freq <= port->maxfreq[i - 1] ? 
                                    port->freq : port->maxfreq[i - 1];
            redundance += port->maxfreq[i - 1] - initfreq[i - 1];
            shortfall += port->freq - initfreq[i - 1]; 
        }
    }
    
    if (shortfall && redundance)
    {
        int radio = shortfall * 256 / redundance;
        if (radio > 256)
        {
            radio = 256;
        }

        for (i = 1;i <= PORT_MAX_CHIPID;i++)
        {
            int diff = port->maxfreq[i - 1] - initfreq[i - 1];
            if ((port->chip_map & (1 << i)) && diff > 0)
            {
                initfreq[i - 1] += diff * radio / 256;
                if (initfreq[i - 1] >= 600)
                {
                    initfreq[i - 1] = (initfreq[i - 1] + 24) / 25 * 25;
                } 
                else
                {
                    initfreq[i - 1] = (initfreq[i - 1] + 4) / 5 * 5;
                }
            }
        }
    }

    applog(LOG_INFO,"Max  Freq : %3d %3d %3d %3d %3d %3d %3d %3d",
                             port->maxfreq[0],port->maxfreq[1],port->maxfreq[2],port->maxfreq[3],
                             port->maxfreq[4],port->maxfreq[5],port->maxfreq[6],port->maxfreq[7]);

    applog(LOG_INFO,"Init Freq : %3d %3d %3d %3d %3d %3d %3d %3d",
                             initfreq[0],initfreq[1],initfreq[2],initfreq[3],
                             initfreq[4],initfreq[5],initfreq[6],initfreq[7]);

    return 0;
}

static int sfards_port_sha256d_tune(struct sfards_port *port)
{
    struct sfards_status *status = &port->chip_status[0];
    int correct[9],error[9];
    int i,freq;
    memset(correct,0,sizeof(int) * 9);
    memset(error,0,sizeof(int) * 9);
    if (sfards_port_sha256d_test(port,port->rolltime,1,correct,error) < 0)
    {
        return -1;
    }
    
    for (i = 1;i <= PORT_MAX_CHIPID;i++)
    {
        if ((port->chip_map & (1 << i)) && (correct[i] < 90 || error[i] > 1))
        {
            freq = status->freq;
            if (--status->score < -5 && port->maxfreq[i - 1] - freq < 50)
            {                
                freq -= freq > 600 ? 25 : 5;
            }
            
            if (sfards_port_sha256d_configure(port,i,freq,port->freq + SHA256D_MAX_FREQ_OFFSET) < 0)
            {
                return -1;
            }
        }
        else if (status->score < 5)
        {
            status->score++;
        }
        status++;
    }
    return 0;
}

int sfards_scrypt_control(struct sfards_port *port)
{
    return sfards_port_scrypt_configure(port,port->freq);
}

int sfards_sha256d_control(struct sfards_port *port)
{
    if (!port->scanto)
    {
        if (sfards_port_sha256d_profile(port) < 0)
        {
            return -1;
        }
    }
    else
    {
        if (sfards_port_sha256d_tune(port) < 0)
        {
            return -1;
        }
    }

    if (++port->scanto == 3600)
    {
        port->scanto = 0;
    }

    return 0;
}

struct dev_msg
{
    uint8_t alog;
    uint8_t map;
    uint8_t id;
    uint8_t resv;
    uint32_t accepted;
    uint32_t rejected;
    uint32_t errors;
    uint32_t elapsed;
    float mhs;
};

void sfards_send_devs_msg(struct sfards_port *port,uint8_t map,
                          uint32_t accepted,uint32_t rejected,uint32_t elapsed)
{
    struct dev_msg msg;
    struct sockaddr_in addr;

    if (port->sockfd <= 0)
    {
        return;
    }
    msg.alog = port->type;
    msg.map = map;
    msg.id = port->id;
    msg.resv = 0;
    msg.accepted = accepted;
    msg.rejected = rejected;
    msg.errors = port->errors;
    msg.elapsed = elapsed;
    msg.mhs = port->hashrate;

    memset(&addr,0,sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(7678);
    addr.sin_addr.s_addr =inet_addr("127.0.0.1");

    sendto(port->sockfd,&msg,sizeof(msg), 0,(struct sockaddr *)&addr,sizeof(addr));    
}

void sfards_destroy(struct sfards_dev *dev)
{
    int i;

    dev->exit = 1;

    if (dev->thr > 0)
    {
        sfards_thr_exit(dev);
        pthread_join(dev->thr,NULL);        
    }
    
    for (i = 0;i < PORT_MAX_COUNT;i++)
    {
        struct sfards_port *port = &dev->port[i];
        if (port->fd > 0)
        {
            close(port->fd);
        }
    }

    close(dev->pipefd[0]);
    close(dev->pipefd[1]);
    close(dev->epollfd);
    free(dev);
}

