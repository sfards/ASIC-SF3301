#ifndef  __SFARDS_H__
#define  __SFARDS_H__
#include <stdint.h>
#include <time.h>
#include <pthread.h>
#include "miner.h"

#define PORT_BUF_SIZE				(1024)
#define PORT_NONCE_RPT_COUNT			(128)
#define PORT_NONCE_RPT_MASK			(PORT_NONCE_RPT_COUNT - 1)
#define PORT_MAX_PATH_LENGTH			(64)
#define PORT_MAX_COUNT				(6)
#define PORT_MAX_CHIPID       			(8)
#define PORT_STATUS_NONCE_MAX_COUNT		(16)
#define PORT_STATUS_NONCE_MASK			(PORT_STATUS_NONCE_MAX_COUNT - 1)

enum PORT_TYPE
{
    PORT_TYPE_UNKNOWN = 0,
    PORT_TYPE_SCRYPT  = 1,
    PORT_TYPE_SHA256  = 2,
};

struct sfards_rpt
{
    int chipid;
    int taskid;
    uint32_t data;
};

struct sfards_status
{
    int err_n;
    int nonce_n;
    int roll_n;
    int taskid;
    uint32_t roll_mhash;
    uint32_t nonce_start;
    struct timeval tv_start;
    float hashrate;
    uint32_t nonce[PORT_STATUS_NONCE_MAX_COUNT];
    int curpos;
    int score;
    int freq;
};

struct sfards_port
{
    enum PORT_TYPE type;
    char path[PORT_MAX_PATH_LENGTH];
    int id;
    int fd;
    int baud;
    int freq;
    int rolltime;
    int interval;
    int scanto;
    int chip_n;
    int chip_map;
    uint8_t recv_buf[PORT_BUF_SIZE];
    int recv_offset;
    pthread_mutex_t lock;
    pthread_cond_t cond;
    struct sfards_rpt nonce[PORT_NONCE_RPT_COUNT];
    int ridx;
    int widx;
    int maxfreq[PORT_MAX_CHIPID];
    struct sfards_status chip_status[PORT_MAX_CHIPID];
    float hashrate;
    uint32_t errors;
    int sockfd;
};

struct sfards_dev
{
    enum PORT_TYPE type;
    int port_map;
    struct sfards_port port[PORT_MAX_COUNT];
    int epollfd;
    int pipefd[2];
    int exit;
    pthread_t thr;
};

struct sfards_dev * sfards_new(enum PORT_TYPE type);

int sfards_port_addnew(struct sfards_dev *dev,int index,const char *path,int id,int freq);

int sfards_port_open(struct sfards_dev *dev,int index);

void sfards_port_close(struct sfards_port *port);

void sfards_port_status_update(struct sfards_port *port,int chipid,int taskid,
                               uint32_t nonce,int invalid);
void sfards_port_status_get(struct sfards_port *port,int max_chipid,
                            int *nonce_n,int *err_n,int *freq,float *hashrate);

int sfards_dispatch_scrypt_task(struct sfards_port *port,
                                const uint32_t *ptarget,const uint32_t *midstate,
                                const uint32_t *pdata);

int sfards_dispatch_sha256d_task(struct sfards_port *port,int taskid,
                                 const uint32_t *ptarget,const uint32_t *midstate,
                                 const uint32_t *pdata2,uint32_t ntime);

int sfards_wait_nonce(struct sfards_port *port,
                      struct sfards_rpt *nonce_rpt,int size,struct timespec *ts);

int sfards_scrypt_control(struct sfards_port *port);

int sfards_sha256d_control(struct sfards_port *port);

void sfards_send_devs_msg(struct sfards_port *port,uint8_t map,
                          uint32_t accepted,uint32_t rejected,uint32_t elapsed);
void sfards_destroy(struct sfards_dev *dev);

#endif //__SFARDS_H__


